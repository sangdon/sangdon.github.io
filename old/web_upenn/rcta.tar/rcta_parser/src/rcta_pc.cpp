#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
// PCL specific includes
#include <pcl/ros/conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>

void cloud_cb (const sensor_msgs::PointCloud2::ConstPtr& input)
{
  pcl::PointCloud<pcl::PointXYZ> cloud;
  pcl::fromROSMsg(*input, cloud);
  std_msgs::Header header = input->header;
  ros::Time stamp = header.stamp;
  std::ostringstream t;
  t << stamp.sec << "_" << stamp.nsec;
  std::string filename = t.str() + ".pcd";
  std::cout << "Save " << filename << std::endl;
  pcl::io::savePCDFileASCII (filename, cloud); 
}

int main (int argc, char** argv)
{
  // Initialize ROS
  ros::init (argc, argv, "rcta_pc");
  ros::NodeHandle nh;

  // Create a ROS subscriber for the input point cloud
  ros::Subscriber sub = nh.subscribe ("input", 100, cloud_cb);

  // Spin
  ros::spin ();
}
