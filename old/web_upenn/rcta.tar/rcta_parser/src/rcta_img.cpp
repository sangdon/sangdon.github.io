#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <sstream>
#include <string>
#include <iostream>

static const std::string OPENCV_WINDOW = "Image window";

class ImageConverter
{
  ros::NodeHandle nh_;
  image_transport::ImageTransport it_;
  image_transport::Subscriber image_sub_;
  image_transport::Publisher image_pub_;
  bool vis_;   // Visualization flag  
public:
  ImageConverter()
    : it_(nh_), vis_(false)
  {
    // Subscrive to input video feed and publish output video feed
    image_sub_ = it_.subscribe("/image_sub", 100, 
      &ImageConverter::imageCb, this);
//    image_pub_ = it_.advertise("/image_converter/output_video", 1);
    
    if(vis_ == true) {
      cv::namedWindow(OPENCV_WINDOW);
    }
  }

  ~ImageConverter()
  {
    if(vis_ == true) {
      cv::destroyWindow(OPENCV_WINDOW);
    }
  }

  void imageCb(const sensor_msgs::ImageConstPtr& msg)
  {
    cv_bridge::CvImagePtr cv_ptr;
    std_msgs::Header header;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
      header = cv_ptr->header;
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }
//    std::cout << "Get one." << std::endl;
//    std::cout << header << std::endl;  
    
    ros::Time stamp = header.stamp;
    std::ostringstream t;
    t << stamp.sec << "_" << stamp.nsec;
    std::string filename = t.str() + ".jpg";
    cv::imwrite(filename, cv_ptr->image);
    std::cout << "Save " << filename << std::endl; 
    // Update GUI Window
    if(vis_ == true) {
      cv::imshow(OPENCV_WINDOW, cv_ptr->image);
      cv::waitKey(3);
    }
    // Output modified video stream
//    image_pub_.publish(cv_ptr->toImageMsg());
  }
};

int main(int argc, char** argv)
{
  ros::init(argc, argv, "image_converter");
  ImageConverter ic;
  ros::spin();
  return 0;
}
